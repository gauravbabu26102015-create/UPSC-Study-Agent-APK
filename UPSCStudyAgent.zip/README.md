# UPSC Study Agent 📚

A comprehensive Android app for UPSC Civil Services Examination preparation with 6 major features.

## Features

### 1. Smart Dashboard
- Time-based greetings
- Daily motivational quotes from IAS toppers and leaders
- Study tips and daily advice
- Quick-access cards to all features

### 2. Multiple Study Alarms
- Subject-specific study alarms with start and end times
- Day-of-week scheduling
- Fullscreen alarm screen with motivational quotes
- Snooze and Dismiss options
- Alarms persist after device reboot

### 3. Quiz System
- Create quizzes manually with custom questions
- Import questions from TXT files
- Interactive quiz with color-coded feedback
- Timer and score tracking with explanations
- Results saved with statistics

### 4. Current Affairs Fetcher
- Auto-fetches from Insights on India, PIB, The Hindu, Indian Express
- Auto-categorizes into Economy, Science, Environment, Polity, etc.
- Bookmark and filter by category
- Background fetch every 6 hours

### 5. UPSC Study Agent
- 25+ motivational quotes, 20+ study tips, 10+ daily advice items
- Subject-specific strategies for all UPSC subjects
- Document library for PDF/HTML/TXT files

### 6. Document Reader
- Read PDF, HTML, and TXT files with appropriate viewers

## How to Build (GitHub Actions - FREE)
1. Push this project to a GitHub repository
2. Go to Actions tab
3. Click "Build UPSC Study Agent APK" then "Run workflow"
4. Wait ~10 minutes then download APK from Artifacts

## Tech Stack
Kotlin, Room Database, WorkManager, Jsoup, Material Design, android-pdf-viewer

## Created by
**RAUSHAN** - UPSC Aspirant and App Developer
