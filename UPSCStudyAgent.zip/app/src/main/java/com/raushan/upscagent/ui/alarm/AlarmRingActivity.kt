package com.raushan.upscagent.ui.alarm

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.raushan.upscagent.R
import com.raushan.upscagent.service.AlarmService
import com.raushan.upscagent.utils.MotivationHelper

class AlarmRingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        setContentView(R.layout.activity_alarm_ring)

        val subject = intent.getStringExtra("subject") ?: "Study Time"
        val isStart = intent.getBooleanExtra("is_start", true)
        val notes = intent.getStringExtra("notes") ?: ""

        val tvSubject = findViewById<TextView>(R.id.tv_ring_subject)
        val tvMessage = findViewById<TextView>(R.id.tv_ring_message)
        val tvMotivation = findViewById<TextView>(R.id.tv_ring_motivation)
        val tvNotes = findViewById<TextView>(R.id.tv_ring_notes)
        val btnDismiss = findViewById<Button>(R.id.btn_dismiss)
        val btnSnooze = findViewById<Button>(R.id.btn_snooze)

        tvSubject.text = subject
        tvMessage.text = if (isStart) "🚀 Time to study!" else "✅ Session complete! Great job!"

        val quote = MotivationHelper.getRandomQuote()
        tvMotivation.text = "\"${quote.text}\"\n— ${quote.author}"

        if (notes.isNotBlank()) {
            tvNotes.text = notes
            tvNotes.visibility = android.view.View.VISIBLE
        }

        btnDismiss.setOnClickListener {
            stopAlarmService()
            finish()
        }

        btnSnooze.setOnClickListener {
            stopAlarmService()
            // Snooze for 5 minutes (could add AlarmManager logic here)
            android.widget.Toast.makeText(this, "Snoozed for 5 minutes", android.widget.Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun stopAlarmService() {
        stopService(Intent(this, AlarmService::class.java))
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Prevent dismissing alarm with back button
    }
}
