package com.raushan.upscagent.utils

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.raushan.upscagent.data.model.StudyAlarm
import com.raushan.upscagent.receiver.AlarmReceiver
import java.util.Calendar

object AlarmHelper {

    private const val START_ALARM_BASE = 10000
    private const val END_ALARM_BASE = 20000

    fun scheduleAlarm(context: Context, alarm: StudyAlarm) {
        if (!alarm.isEnabled) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // Check permission for exact alarms on Android 12+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!alarmManager.canScheduleExactAlarms()) return
        }

        val enabledDays = alarm.daysOfWeek.split(",").mapNotNull { it.trim().toIntOrNull() }
        if (enabledDays.isEmpty()) return

        // Schedule START alarm
        val startTime = getNextAlarmTime(alarm.startHour, alarm.startMinute, enabledDays)
        val startIntent = createAlarmIntent(context, alarm, isStart = true)

        try {
            alarmManager.setAlarmClock(
                AlarmManager.AlarmClockInfo(startTime, startIntent),
                startIntent
            )
        } catch (e: SecurityException) {
            e.printStackTrace()
        }

        // Schedule END alarm
        val endTime = getNextAlarmTime(alarm.endHour, alarm.endMinute, enabledDays)
        val endIntent = createAlarmIntent(context, alarm, isStart = false)

        try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                endTime,
                endIntent
            )
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    fun cancelAlarm(context: Context, alarm: StudyAlarm) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(createAlarmIntent(context, alarm, isStart = true))
        alarmManager.cancel(createAlarmIntent(context, alarm, isStart = false))
    }

    private fun createAlarmIntent(context: Context, alarm: StudyAlarm, isStart: Boolean): PendingIntent {
        val requestCode = if (isStart) (START_ALARM_BASE + alarm.id.toInt()) else (END_ALARM_BASE + alarm.id.toInt())
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("alarm_id", alarm.id)
            putExtra("subject", alarm.subject)
            putExtra("is_start", isStart)
            putExtra("notes", alarm.notes)
            action = "com.raushan.upscagent.ALARM_${alarm.id}_${if (isStart) "START" else "END"}"
        }
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun getNextAlarmTime(hour: Int, minute: Int, enabledDays: List<Int>): Long {
        val now = Calendar.getInstance()
        val alarm = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // Convert Calendar day to our format (1=Mon...7=Sun)
        fun calDayToOurDay(calDay: Int): Int = when (calDay) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            Calendar.SUNDAY -> 7
            else -> 1
        }

        fun ourDayToCalDay(ourDay: Int): Int = when (ourDay) {
            1 -> Calendar.MONDAY
            2 -> Calendar.TUESDAY
            3 -> Calendar.WEDNESDAY
            4 -> Calendar.THURSDAY
            5 -> Calendar.FRIDAY
            6 -> Calendar.SATURDAY
            7 -> Calendar.SUNDAY
            else -> Calendar.MONDAY
        }

        val todayOurDay = calDayToOurDay(now.get(Calendar.DAY_OF_WEEK))

        // If today is enabled and alarm time is in the future, use today
        if (todayOurDay in enabledDays && alarm.after(now)) {
            return alarm.timeInMillis
        }

        // Find next enabled day
        for (i in 1..7) {
            val nextDay = ((todayOurDay - 1 + i) % 7) + 1
            if (nextDay in enabledDays) {
                alarm.set(Calendar.DAY_OF_WEEK, ourDayToCalDay(nextDay))
                if (alarm.before(now) || alarm == now) {
                    alarm.add(Calendar.WEEK_OF_YEAR, 1)
                }
                return alarm.timeInMillis
            }
        }

        // Fallback: set for tomorrow
        alarm.add(Calendar.DAY_OF_YEAR, 1)
        return alarm.timeInMillis
    }

    fun formatTime(hour: Int, minute: Int): String {
        val amPm = if (hour < 12) "AM" else "PM"
        val h = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
        return String.format("%d:%02d %s", h, minute, amPm)
    }

    fun formatDays(daysOfWeek: String): String {
        val dayNames = mapOf(1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu", 5 to "Fri", 6 to "Sat", 7 to "Sun")
        val days = daysOfWeek.split(",").mapNotNull { it.trim().toIntOrNull() }
        if (days.size == 7) return "Every day"
        if (days.containsAll(listOf(1, 2, 3, 4, 5)) && days.size == 5) return "Weekdays"
        if (days.containsAll(listOf(6, 7)) && days.size == 2) return "Weekends"
        return days.mapNotNull { dayNames[it] }.joinToString(", ")
    }
}
