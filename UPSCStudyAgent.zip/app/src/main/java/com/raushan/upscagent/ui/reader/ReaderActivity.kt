package com.raushan.upscagent.ui.reader

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.barteksc.pdfviewer.PDFView
import com.raushan.upscagent.R
import java.io.BufferedReader
import java.io.InputStreamReader

class ReaderActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reader)

        val docUri = intent.getStringExtra("doc_uri") ?: ""
        val docName = intent.getStringExtra("doc_name") ?: "Document"
        val docType = intent.getStringExtra("doc_type") ?: "txt"

        val tvTitle = findViewById<TextView>(R.id.tv_reader_title)
        val pdfView = findViewById<PDFView>(R.id.pdf_view)
        val webView = findViewById<WebView>(R.id.web_view)
        val scrollText = findViewById<ScrollView>(R.id.scroll_text_reader)
        val tvContent = findViewById<TextView>(R.id.tv_text_content)
        val progress = findViewById<ProgressBar>(R.id.progress_reader)
        val btnBack = findViewById<ImageButton>(R.id.btn_back_reader)

        tvTitle.text = docName
        btnBack.setOnClickListener { finish() }

        val uri = Uri.parse(docUri)

        try {
            when (docType) {
                "pdf" -> {
                    pdfView.visibility = View.VISIBLE
                    progress.visibility = View.VISIBLE
                    pdfView.fromUri(uri)
                        .enableSwipe(true)
                        .swipeHorizontal(false)
                        .enableDoubletap(true)
                        .enableAntialiasing(true)
                        .onLoad { _ -> progress.visibility = View.GONE }
                        .onError { e ->
                            progress.visibility = View.GONE
                            Toast.makeText(this, "Error loading PDF: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                        .load()
                }
                "html", "htm" -> {
                    webView.visibility = View.VISIBLE
                    webView.settings.javaScriptEnabled = true
                    webView.settings.builtInZoomControls = true
                    webView.settings.displayZoomControls = false

                    try {
                        val inputStream = contentResolver.openInputStream(uri)
                        val html = inputStream?.bufferedReader()?.readText() ?: ""
                        inputStream?.close()
                        webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                    } catch (e: Exception) {
                        webView.loadUrl(docUri)
                    }
                }
                else -> { // txt and others
                    scrollText.visibility = View.VISIBLE
                    try {
                        val inputStream = contentResolver.openInputStream(uri)
                        val reader = BufferedReader(InputStreamReader(inputStream))
                        val text = reader.readText()
                        reader.close()
                        tvContent.text = text
                    } catch (e: Exception) {
                        tvContent.text = "Error loading file: ${e.message}"
                    }
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
