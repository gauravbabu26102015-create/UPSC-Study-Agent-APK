package com.raushan.upscagent.ui.home

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.raushan.upscagent.R
import com.raushan.upscagent.ui.agent.AgentFragment
import com.raushan.upscagent.ui.alarm.AlarmFragment
import com.raushan.upscagent.ui.currentaffairs.CurrentAffairsFragment
import com.raushan.upscagent.ui.quiz.QuizFragment

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestPermissions()

        bottomNav = findViewById(R.id.bottom_nav)

        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }

        // Check if opened from notification
        val openTab = intent.getStringExtra("open_tab")
        if (openTab == "current_affairs") {
            bottomNav.selectedItemId = R.id.nav_current_affairs
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> loadFragment(HomeFragment())
                R.id.nav_alarm -> loadFragment(AlarmFragment())
                R.id.nav_quiz -> loadFragment(QuizFragment())
                R.id.nav_current_affairs -> loadFragment(CurrentAffairsFragment())
                R.id.nav_agent -> loadFragment(AgentFragment())
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment): Boolean {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
        return true
    }

    private fun requestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), 100)
        }
    }
}
