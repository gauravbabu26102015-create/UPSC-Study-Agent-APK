package com.raushan.upscagent.ui.alarm

import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.switchmaterial.SwitchMaterial
import com.raushan.upscagent.R
import com.raushan.upscagent.data.model.StudyAlarm
import com.raushan.upscagent.data.repository.AppRepository
import com.raushan.upscagent.utils.AlarmHelper
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AlarmFragment : Fragment() {

    private lateinit var repository: AppRepository
    private lateinit var adapter: AlarmAdapter
    private val alarms = mutableListOf<StudyAlarm>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_alarm, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repository = AppRepository.getInstance(requireContext())

        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_alarms)
        val fabAdd = view.findViewById<FloatingActionButton>(R.id.fab_add_alarm)
        val tvEmpty = view.findViewById<TextView>(R.id.tv_empty_alarms)

        adapter = AlarmAdapter(
            alarms,
            onToggle = { alarm, enabled -> toggleAlarm(alarm, enabled) },
            onDelete = { alarm -> deleteAlarm(alarm) }
        )
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        fabAdd.setOnClickListener { showAddAlarmDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getAllAlarms().collectLatest { list ->
                alarms.clear()
                alarms.addAll(list)
                adapter.notifyDataSetChanged()
                tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun showAddAlarmDialog() {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_alarm, null)
        val etSubject = dialogView.findViewById<EditText>(R.id.et_alarm_subject)
        val tvStartTime = dialogView.findViewById<TextView>(R.id.tv_start_time)
        val tvEndTime = dialogView.findViewById<TextView>(R.id.tv_end_time)
        val etNotes = dialogView.findViewById<EditText>(R.id.et_alarm_notes)
        val chipGroup = dialogView.findViewById<ChipGroup>(R.id.chip_group_days)

        var startH = 8; var startM = 0; var endH = 10; var endM = 0
        tvStartTime.text = AlarmHelper.formatTime(startH, startM)
        tvEndTime.text = AlarmHelper.formatTime(endH, endM)

        tvStartTime.setOnClickListener {
            TimePickerDialog(context, { _, h, m ->
                startH = h; startM = m
                tvStartTime.text = AlarmHelper.formatTime(h, m)
            }, startH, startM, false).show()
        }

        tvEndTime.setOnClickListener {
            TimePickerDialog(context, { _, h, m ->
                endH = h; endM = m
                tvEndTime.text = AlarmHelper.formatTime(h, m)
            }, endH, endM, false).show()
        }

        // Pre-check all day chips
        for (i in 0 until chipGroup.childCount) {
            (chipGroup.getChildAt(i) as? Chip)?.isChecked = true
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Add Study Alarm")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val subject = etSubject.text.toString().trim()
                if (subject.isBlank()) {
                    Toast.makeText(context, "Enter a subject name", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val selectedDays = mutableListOf<Int>()
                for (i in 0 until chipGroup.childCount) {
                    val chip = chipGroup.getChildAt(i) as? Chip
                    if (chip?.isChecked == true) selectedDays.add(i + 1)
                }
                if (selectedDays.isEmpty()) selectedDays.addAll(1..7)

                val alarm = StudyAlarm(
                    subject = subject,
                    startHour = startH, startMinute = startM,
                    endHour = endH, endMinute = endM,
                    daysOfWeek = selectedDays.joinToString(","),
                    notes = etNotes.text.toString().trim()
                )

                viewLifecycleOwner.lifecycleScope.launch {
                    val id = repository.insertAlarm(alarm)
                    AlarmHelper.scheduleAlarm(requireContext(), alarm.copy(id = id))
                    Toast.makeText(context, "Alarm set for $subject", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleAlarm(alarm: StudyAlarm, enabled: Boolean) {
        val updated = alarm.copy(isEnabled = enabled)
        viewLifecycleOwner.lifecycleScope.launch {
            repository.updateAlarm(updated)
            if (enabled) AlarmHelper.scheduleAlarm(requireContext(), updated)
            else AlarmHelper.cancelAlarm(requireContext(), alarm)
        }
    }

    private fun deleteAlarm(alarm: StudyAlarm) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Alarm")
            .setMessage("Delete alarm for ${alarm.subject}?")
            .setPositiveButton("Delete") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    AlarmHelper.cancelAlarm(requireContext(), alarm)
                    repository.deleteAlarm(alarm)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ========== Adapter ==========
    class AlarmAdapter(
        private val alarms: List<StudyAlarm>,
        private val onToggle: (StudyAlarm, Boolean) -> Unit,
        private val onDelete: (StudyAlarm) -> Unit
    ) : RecyclerView.Adapter<AlarmAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvSubject: TextView = view.findViewById(R.id.tv_alarm_subject)
            val tvTime: TextView = view.findViewById(R.id.tv_alarm_time)
            val tvDays: TextView = view.findViewById(R.id.tv_alarm_days)
            val switchEnable: SwitchMaterial = view.findViewById(R.id.switch_alarm)
            val btnDelete: View = view.findViewById(R.id.btn_delete_alarm)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_alarm, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val alarm = alarms[position]
            holder.tvSubject.text = alarm.subject
            holder.tvTime.text = "${AlarmHelper.formatTime(alarm.startHour, alarm.startMinute)} → ${AlarmHelper.formatTime(alarm.endHour, alarm.endMinute)}"
            holder.tvDays.text = AlarmHelper.formatDays(alarm.daysOfWeek)
            holder.switchEnable.isChecked = alarm.isEnabled
            holder.switchEnable.setOnCheckedChangeListener { _, isChecked -> onToggle(alarm, isChecked) }
            holder.btnDelete.setOnClickListener { onDelete(alarm) }
        }

        override fun getItemCount() = alarms.size
    }
}
