package com.raushan.upscagent

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.work.*
import com.raushan.upscagent.worker.CurrentAffairsWorker
import java.util.concurrent.TimeUnit

class UPSCAgentApp : Application() {

    companion object {
        const val CHANNEL_ALARM = "alarm_channel"
        const val CHANNEL_AFFAIRS = "current_affairs_channel"
        const val CHANNEL_MOTIVATION = "motivation_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        scheduleCurrentAffairsFetch()
    }

    private fun createNotificationChannels() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val alarmChannel = NotificationChannel(
            CHANNEL_ALARM,
            "Study Alarms",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifications for study session alarms"
            enableVibration(true)
            setSound(null, null) // We handle sound in AlarmService
        }

        val affairsChannel = NotificationChannel(
            CHANNEL_AFFAIRS,
            "Current Affairs",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Notifications for new current affairs"
        }

        val motivationChannel = NotificationChannel(
            CHANNEL_MOTIVATION,
            "Motivation",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Daily motivational quotes and tips"
        }

        manager.createNotificationChannel(alarmChannel)
        manager.createNotificationChannel(affairsChannel)
        manager.createNotificationChannel(motivationChannel)
    }

    private fun scheduleCurrentAffairsFetch() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val workRequest = PeriodicWorkRequestBuilder<CurrentAffairsWorker>(
            6, TimeUnit.HOURS,
            30, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 15, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "current_affairs_fetch",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
    }
}
