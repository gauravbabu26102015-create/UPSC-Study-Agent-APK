package com.raushan.upscagent.utils

import android.content.Context
import android.net.Uri
import com.raushan.upscagent.data.model.Question
import java.io.BufferedReader
import java.io.InputStreamReader

object PDFQuizParser {

    data class ParseResult(
        val questions: List<Question>,
        val errors: List<String>,
        val totalFound: Int
    )

    /**
     * Parse text content to extract quiz questions.
     * Supports formats:
     * Q1. / 1. / Question 1: for questions
     * (a) / a) / A) / a. for options
     * Answer: A / Ans: (b) for correct answers
     * Explanation: for explanations
     */
    fun parseText(text: String, quizId: Long): ParseResult {
        val questions = mutableListOf<Question>()
        val errors = mutableListOf<String>()
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }

        var i = 0
        var questionNumber = 0

        while (i < lines.size) {
            val line = lines[i]

            // Detect question start
            val questionMatch = Regex("""^(?:Q\.?\s*(\d+)|(\d+)\s*[\.\)]\s*|Question\s+(\d+)\s*[:\.]?\s*)(.+)""", RegexOption.IGNORE_CASE).find(line)

            if (questionMatch != null) {
                questionNumber++
                var questionText = questionMatch.groupValues[4].trim()

                // Collect multi-line question text
                i++
                while (i < lines.size && !isOptionLine(lines[i]) && !isQuestionLine(lines[i])) {
                    questionText += " " + lines[i]
                    i++
                }

                // Parse options
                val options = mutableListOf("", "", "", "")
                var optionIndex = 0

                while (i < lines.size && isOptionLine(lines[i]) && optionIndex < 4) {
                    val optionText = extractOptionText(lines[i])
                    options[optionIndex] = optionText
                    optionIndex++
                    i++

                    // Collect multi-line option text
                    while (i < lines.size && !isOptionLine(lines[i]) && !isAnswerLine(lines[i]) && !isQuestionLine(lines[i]) && !isExplanationLine(lines[i])) {
                        options[optionIndex - 1] += " " + lines[i]
                        i++
                    }
                }

                // Parse answer
                var correctAnswer = 0
                if (i < lines.size && isAnswerLine(lines[i])) {
                    correctAnswer = extractAnswer(lines[i])
                    i++
                }

                // Parse explanation
                var explanation = ""
                if (i < lines.size && isExplanationLine(lines[i])) {
                    explanation = lines[i].replace(Regex("""^(?:Explanation|Exp|Note)\s*[:\-]\s*""", RegexOption.IGNORE_CASE), "").trim()
                    i++
                    // Multi-line explanation
                    while (i < lines.size && !isQuestionLine(lines[i])) {
                        explanation += " " + lines[i]
                        i++
                    }
                }

                // Validate and add
                if (questionText.isNotBlank() && options[0].isNotBlank() && options[1].isNotBlank()) {
                    questions.add(
                        Question(
                            quizId = quizId,
                            questionText = questionText.trim(),
                            optionA = options[0].trim(),
                            optionB = options[1].trim(),
                            optionC = options[2].trim(),
                            optionD = options[3].trim(),
                            correctAnswer = correctAnswer,
                            explanation = explanation.trim()
                        )
                    )
                } else {
                    errors.add("Question $questionNumber: incomplete (missing options)")
                }
            } else {
                i++
            }
        }

        return ParseResult(questions, errors, questions.size)
    }

    fun readTextFromUri(context: Context, uri: Uri): String {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val reader = BufferedReader(InputStreamReader(inputStream))
            val text = reader.readText()
            reader.close()
            text
        } catch (e: Exception) {
            ""
        }
    }

    private fun isQuestionLine(line: String): Boolean {
        return Regex("""^(?:Q\.?\s*\d+|(\d+)\s*[\.\)]\s*|Question\s+\d+)""", RegexOption.IGNORE_CASE).containsMatchIn(line)
    }

    private fun isOptionLine(line: String): Boolean {
        return Regex("""^(?:\(?[a-dA-D1-4]\s*[\.\)]\s*|[a-dA-D]\s*[\.\)]\s*)""").containsMatchIn(line)
    }

    private fun isAnswerLine(line: String): Boolean {
        return Regex("""^(?:Answer|Ans|Correct)\s*[:\-]""", RegexOption.IGNORE_CASE).containsMatchIn(line)
    }

    private fun isExplanationLine(line: String): Boolean {
        return Regex("""^(?:Explanation|Exp|Note)\s*[:\-]""", RegexOption.IGNORE_CASE).containsMatchIn(line)
    }

    private fun extractOptionText(line: String): String {
        return line.replace(Regex("""^(?:\(?[a-dA-D1-4]\s*[\.\)]\s*|[a-dA-D]\s*[\.\)]\s*)"""), "").trim()
    }

    private fun extractAnswer(line: String): Int {
        val answerText = line.replace(Regex("""^(?:Answer|Ans|Correct)\s*[:\-]\s*\(?""", RegexOption.IGNORE_CASE), "")
            .trim().uppercase().firstOrNull() ?: 'A'
        return when (answerText) {
            'A', '1' -> 0
            'B', '2' -> 1
            'C', '3' -> 2
            'D', '4' -> 3
            else -> 0
        }
    }
}
