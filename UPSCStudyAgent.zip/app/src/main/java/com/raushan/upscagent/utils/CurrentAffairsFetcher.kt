package com.raushan.upscagent.utils

import com.raushan.upscagent.data.model.CurrentAffair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

object CurrentAffairsFetcher {

    private const val TIMEOUT = 15000

    suspend fun fetchAll(): List<CurrentAffair> = withContext(Dispatchers.IO) {
        val allAffairs = mutableListOf<CurrentAffair>()

        try { allAffairs.addAll(fetchInsightsOnIndia()) } catch (e: Exception) { e.printStackTrace() }
        try { allAffairs.addAll(fetchPIB()) } catch (e: Exception) { e.printStackTrace() }
        try { allAffairs.addAll(fetchTheHinduRSS()) } catch (e: Exception) { e.printStackTrace() }
        try { allAffairs.addAll(fetchIndianExpressExplained()) } catch (e: Exception) { e.printStackTrace() }

        // Deduplicate by title
        allAffairs.distinctBy { it.title.lowercase().trim() }
    }

    private fun fetchInsightsOnIndia(): List<CurrentAffair> {
        val affairs = mutableListOf<CurrentAffair>()
        try {
            val doc = Jsoup.connect("https://www.insightsonindia.com/")
                .timeout(TIMEOUT)
                .userAgent("Mozilla/5.0")
                .get()

            val articles = doc.select("article.post, .entry-content h2 a, .td-module-title a")
            for (article in articles.take(15)) {
                val title = article.text().trim()
                val link = if (article.tagName() == "a") article.attr("abs:href")
                else article.select("a").firstOrNull()?.attr("abs:href") ?: ""

                if (title.length > 10) {
                    affairs.add(
                        CurrentAffair(
                            title = title,
                            summary = title,
                            source = "Insights on India",
                            sourceUrl = link,
                            category = categorize(title)
                        )
                    )
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        return affairs
    }

    private fun fetchPIB(): List<CurrentAffair> {
        val affairs = mutableListOf<CurrentAffair>()
        try {
            val doc = Jsoup.connect("https://pib.gov.in/allRel.aspx")
                .timeout(TIMEOUT)
                .userAgent("Mozilla/5.0")
                .get()

            val items = doc.select(".content_list ul li a, .release_list a")
            for (item in items.take(15)) {
                val title = item.text().trim()
                val link = item.attr("abs:href")

                if (title.length > 10) {
                    affairs.add(
                        CurrentAffair(
                            title = title,
                            summary = title,
                            source = "PIB",
                            sourceUrl = link,
                            category = categorize(title)
                        )
                    )
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        return affairs
    }

    private fun fetchTheHinduRSS(): List<CurrentAffair> {
        val affairs = mutableListOf<CurrentAffair>()
        try {
            val doc = Jsoup.connect("https://www.thehindu.com/news/national/feeder/default.rss")
                .timeout(TIMEOUT)
                .userAgent("Mozilla/5.0")
                .ignoreContentType(true)
                .get()

            val items = doc.select("item")
            for (item in items.take(15)) {
                val title = item.select("title").text().trim()
                val description = item.select("description").text().trim()
                val link = item.select("link").text().trim()

                if (title.length > 10) {
                    affairs.add(
                        CurrentAffair(
                            title = title,
                            summary = if (description.length > 200) description.substring(0, 200) + "..." else description,
                            content = description,
                            source = "The Hindu",
                            sourceUrl = link,
                            category = categorize(title + " " + description)
                        )
                    )
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        return affairs
    }

    private fun fetchIndianExpressExplained(): List<CurrentAffair> {
        val affairs = mutableListOf<CurrentAffair>()
        try {
            val doc = Jsoup.connect("https://indianexpress.com/section/explained/")
                .timeout(TIMEOUT)
                .userAgent("Mozilla/5.0")
                .get()

            val articles = doc.select("h2.title a, .articles h2 a, .title a")
            for (article in articles.take(10)) {
                val title = article.text().trim()
                val link = article.attr("abs:href")

                if (title.length > 10) {
                    affairs.add(
                        CurrentAffair(
                            title = title,
                            summary = title,
                            source = "Indian Express",
                            sourceUrl = link,
                            category = categorize(title)
                        )
                    )
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
        return affairs
    }

    private fun categorize(text: String): String {
        val lowerText = text.lowercase()
        return when {
            // Economy
            lowerText.containsAny("economy", "gdp", "rbi", "inflation", "fiscal", "budget", "tax", "gst", "bank", "trade", "export", "import", "stock", "market", "rupee", "monetary", "sebi", "nifty") -> "Economy"
            // Science & Technology
            lowerText.containsAny("isro", "nasa", "satellite", "space", "ai", "artificial intelligence", "technology", "digital", "cyber", "robot", "quantum", "5g", "research", "science", "drdo") -> "Science & Tech"
            // Environment
            lowerText.containsAny("environment", "climate", "pollution", "wildlife", "forest", "biodiversity", "carbon", "emission", "conservation", "renewable", "solar", "water", "river", "flood", "drought", "cop28", "green") -> "Environment"
            // Polity & Governance
            lowerText.containsAny("supreme court", "parliament", "bill", "amendment", "election", "governor", "constitution", "judiciary", "lok sabha", "rajya sabha", "cabinet", "policy", "scheme", "commission") -> "Polity"
            // International
            lowerText.containsAny("china", "usa", "america", "russia", "pakistan", "un", "g20", "nato", "summit", "bilateral", "foreign", "diplomatic", "global", "world", "ukraine", "israel", "gaza") -> "International"
            // Defence
            lowerText.containsAny("army", "navy", "air force", "defence", "military", "missile", "security", "border", "terrorism", "naxal", "exercise") -> "Defence"
            // Social
            lowerText.containsAny("education", "health", "poverty", "women", "child", "caste", "tribal", "welfare", "ngo", "rural", "urban", "population") -> "Social"
            else -> "National"
        }
    }

    private fun String.containsAny(vararg keywords: String): Boolean {
        return keywords.any { this.contains(it) }
    }
}
