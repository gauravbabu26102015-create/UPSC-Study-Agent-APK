package com.raushan.upscagent.utils

import java.util.Calendar

object MotivationHelper {

    data class Quote(val text: String, val author: String)

    private val quotes = listOf(
        Quote("Success is not final, failure is not fatal: it is the courage to continue that counts.", "Winston Churchill"),
        Quote("The future belongs to those who believe in the beauty of their dreams.", "APJ Abdul Kalam"),
        Quote("You have to dream before your dreams can come true.", "APJ Abdul Kalam"),
        Quote("Be the change that you wish to see in the world.", "Mahatma Gandhi"),
        Quote("In a gentle way, you can shake the world.", "Mahatma Gandhi"),
        Quote("The best time to plant a tree was 20 years ago. The second best time is now.", "Chinese Proverb"),
        Quote("Hard work beats talent when talent doesn't work hard.", "Tim Notke"),
        Quote("Discipline is the bridge between goals and accomplishment.", "Jim Rohn"),
        Quote("I hated every minute of training, but I said, 'Don't quit. Suffer now and live the rest of your life as a champion.'", "Muhammad Ali"),
        Quote("Success usually comes to those who are too busy to be looking for it.", "Henry David Thoreau"),
        Quote("Don't watch the clock; do what it does. Keep going.", "Sam Levenson"),
        Quote("The only way to do great work is to love what you do.", "Steve Jobs"),
        Quote("UPSC is not about intelligence, it's about consistency and persistence.", "IAS Topper"),
        Quote("Your preparation today determines your success tomorrow.", "IAS Topper"),
        Quote("Every expert was once a beginner. Keep studying.", "IAS Topper"),
        Quote("The syllabus is vast, but your determination should be vaster.", "IAS Topper"),
        Quote("Read less, revise more. Quality over quantity.", "IAS Topper"),
        Quote("One day you will thank yourself for not giving up today.", "IAS Topper"),
        Quote("UPSC teaches you patience — the most important virtue of a civil servant.", "IAS Topper"),
        Quote("A river cuts through rock not because of its power, but because of its persistence.", "Jim Watkins"),
        Quote("Education is the most powerful weapon which you can use to change the world.", "Nelson Mandela"),
        Quote("The secret of getting ahead is getting started.", "Mark Twain"),
        Quote("Believe you can and you're halfway there.", "Theodore Roosevelt"),
        Quote("It does not matter how slowly you go as long as you do not stop.", "Confucius"),
        Quote("Strength does not come from winning. Your struggles develop your strengths.", "Arnold Schwarzenegger")
    )

    private val studyTips = listOf(
        "Make short notes while reading — they'll save you during revision.",
        "Use the Pomodoro technique: 50 min study + 10 min break.",
        "Read the newspaper daily — Hindu or Indian Express. Underline important news.",
        "Revise every topic within 24 hours of first reading to lock it in memory.",
        "Solve previous year papers weekly — they reveal the exam pattern.",
        "Link current affairs with static topics for better answer writing.",
        "Write at least one answer daily to improve writing speed and quality.",
        "Use mind maps for complex topics like Polity amendments or Geography.",
        "Don't skip NCERTs — they form the foundation for every UPSC topic.",
        "Study in 3-hour focused blocks, not scattered 30-minute sessions.",
        "Create mnemonic devices for remembering lists and sequences.",
        "Teach what you've learned to someone else — it deepens understanding.",
        "Maintain a separate notebook for current affairs with monthly compilation.",
        "Solve CSAT paper practice sets weekly to stay sharp.",
        "Read government reports: Economic Survey, India Year Book, ARC reports.",
        "Focus on understanding concepts, not just memorizing facts.",
        "Take a full-length mock test every fortnight to build exam stamina.",
        "Read Laxmikanth for Polity — it's the bible for UPSC.",
        "Keep a daily planner and track your study hours honestly.",
        "Don't compare your preparation with others — every journey is unique."
    )

    private val dailyAdvice = listOf(
        "Start your day with NCERT revision before moving to advanced books.",
        "Today, focus on linking current affairs with your static syllabus topics.",
        "Practice writing 2 GS answers in 15 minutes each — build speed.",
        "Review your weak subjects today — don't keep postponing them.",
        "Read one editorial carefully today and make notes on the key arguments.",
        "Solve 50 MCQs today from any subject to build accuracy.",
        "Today, map 5 important locations on a blank map — strengthen Geography.",
        "Revise the last 3 days' current affairs before sleeping tonight.",
        "Write one essay outline today on a trending topic.",
        "Study the Environment section today — it's high-scoring in Prelims."
    )

    private val subjectAdvice = mapOf(
        "History" to "For History: Start with NCERTs (Class 6-12), then Spectrum for Modern History. For Ancient & Medieval, focus on art, culture, and architecture. Link freedom movement events with dates chronologically. Use timeline charts.",
        "Polity" to "For Polity: Laxmikanth is your primary source. Read every article mentioned. Focus on amendments, schedules, and recent Supreme Court judgments. Compare constitutional provisions of India with other countries.",
        "Geography" to "For Geography: Start with NCERT Class 6-12, then GC Leong. Practice with maps daily. Focus on Indian Geography for Prelims. Understand climate patterns, soil types, and natural vegetation. Use Atlas regularly.",
        "Economy" to "For Economy: Read Ramesh Singh or Sriram's IAS notes. Follow RBI policies, Union Budget, and Economic Survey. Understand basic concepts deeply: GDP, inflation, fiscal policy, monetary policy. Read Mint/Economic Times.",
        "Environment" to "For Environment: Shankar IAS Environment book is sufficient. Focus on biodiversity hotspots, national parks, international conventions. Current affairs are crucial — follow IUCN, UNFCCC updates. High-scoring topic!",
        "Science & Technology" to "For Science & Tech: Focus on ISRO missions, defense technology, biotechnology, AI developments. Read Science Reporter magazine. Cover NCERT Science books. Current affairs dominate this section.",
        "Ethics" to "For Ethics: Read Lexicon + Subba Rao's book. Practice case studies regularly. Build a personal quote bank for key thinkers. Write answers using real-life examples and anecdotes. Focus on integrity, empathy, and governance.",
        "International Relations" to "For IR: Follow MEA website, IDSA, and ORF publications. Know India's relations with neighbors, US, China, Russia. Study international organizations: UN, WTO, BRICS, SCO, QUAD. Link with current events.",
        "Art & Culture" to "For Art & Culture: NCERT Fine Arts Class 11-12 + Nitin Singhania. Cover dance forms, music, painting styles, architecture, sculptures, and UNESCO heritage sites. Make visual flashcards for better retention.",
        "Essay" to "For Essay: Read widely — editorials, magazines, books. Maintain a quote bank organized by theme. Practice essay writing weekly. Structure: Intro → Body (multiple dimensions) → Conclusion. Include data, examples, and balanced views."
    )

    fun getRandomQuote(): Quote = quotes.random()

    fun getRandomTip(): String = studyTips.random()

    fun getDailyAdvice(): String {
        val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        return dailyAdvice[dayOfYear % dailyAdvice.size]
    }

    fun getSubjectAdvice(subject: String): String {
        return subjectAdvice[subject] ?: "Focus on building strong fundamentals. Read NCERTs first, then move to standard reference books. Practice answer writing regularly."
    }

    fun getAllSubjects(): List<String> = subjectAdvice.keys.toList()

    fun getGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour < 5 -> "🌙 Burning the midnight oil? Great dedication!"
            hour < 8 -> "🌅 Good Morning! Early birds catch the IAS seat!"
            hour < 12 -> "☀️ Good Morning! Make this study session count!"
            hour < 15 -> "🌤️ Good Afternoon! Stay focused after lunch!"
            hour < 18 -> "🌇 Good Evening! Keep the momentum going!"
            hour < 21 -> "🌙 Evening session! You're almost there for today!"
            else -> "🌑 Late night study? Remember to sleep well too!"
        }
    }
}
