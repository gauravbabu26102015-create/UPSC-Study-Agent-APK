package com.raushan.upscagent.data.db

import android.content.Context
import androidx.room.*
import com.raushan.upscagent.data.model.*
import kotlinx.coroutines.flow.Flow

// ==================== DAOs ====================

@Dao
interface AlarmDao {
    @Query("SELECT * FROM study_alarms ORDER BY startHour, startMinute")
    fun getAllAlarms(): Flow<List<StudyAlarm>>

    @Query("SELECT * FROM study_alarms WHERE isEnabled = 1")
    suspend fun getEnabledAlarms(): List<StudyAlarm>

    @Query("SELECT * FROM study_alarms WHERE id = :id")
    suspend fun getAlarmById(id: Long): StudyAlarm?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(alarm: StudyAlarm): Long

    @Update
    suspend fun updateAlarm(alarm: StudyAlarm)

    @Delete
    suspend fun deleteAlarm(alarm: StudyAlarm)

    @Query("DELETE FROM study_alarms WHERE id = :id")
    suspend fun deleteAlarmById(id: Long)
}

@Dao
interface QuizDao {
    @Query("SELECT * FROM quizzes ORDER BY createdAt DESC")
    fun getAllQuizzes(): Flow<List<Quiz>>

    @Query("SELECT * FROM quizzes WHERE id = :id")
    suspend fun getQuizById(id: Long): Quiz?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuiz(quiz: Quiz): Long

    @Update
    suspend fun updateQuiz(quiz: Quiz)

    @Delete
    suspend fun deleteQuiz(quiz: Quiz)

    @Query("UPDATE quizzes SET questionCount = (SELECT COUNT(*) FROM questions WHERE quizId = :quizId) WHERE id = :quizId")
    suspend fun updateQuestionCount(quizId: Long)
}

@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions WHERE quizId = :quizId ORDER BY id")
    suspend fun getQuestionsForQuiz(quizId: Long): List<Question>

    @Query("SELECT COUNT(*) FROM questions WHERE quizId = :quizId")
    suspend fun getQuestionCount(quizId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: Question): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<Question>)

    @Delete
    suspend fun deleteQuestion(question: Question)
}

@Dao
interface QuizResultDao {
    @Query("SELECT * FROM quiz_results ORDER BY completedAt DESC")
    fun getAllResults(): Flow<List<QuizResult>>

    @Insert
    suspend fun insertResult(result: QuizResult): Long
}

@Dao
interface CurrentAffairsDao {
    @Query("SELECT * FROM current_affairs ORDER BY publishedAt DESC")
    fun getAllAffairs(): Flow<List<CurrentAffair>>

    @Query("SELECT * FROM current_affairs WHERE category = :category ORDER BY publishedAt DESC")
    fun getAffairsByCategory(category: String): Flow<List<CurrentAffair>>

    @Query("SELECT * FROM current_affairs WHERE isBookmarked = 1 ORDER BY publishedAt DESC")
    fun getBookmarkedAffairs(): Flow<List<CurrentAffair>>

    @Query("SELECT * FROM current_affairs WHERE id = :id")
    suspend fun getAffairById(id: Long): CurrentAffair?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAffair(affair: CurrentAffair): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAffairs(affairs: List<CurrentAffair>)

    @Update
    suspend fun updateAffair(affair: CurrentAffair)

    @Query("UPDATE current_affairs SET isBookmarked = :bookmarked WHERE id = :id")
    suspend fun setBookmarked(id: Long, bookmarked: Boolean)

    @Query("UPDATE current_affairs SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("SELECT COUNT(*) FROM current_affairs WHERE title = :title")
    suspend fun countByTitle(title: String): Int

    @Query("DELETE FROM current_affairs WHERE fetchedAt < :before AND isBookmarked = 0")
    suspend fun deleteOldAffairs(before: Long)
}

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY lastOpenedAt DESC, addedAt DESC")
    fun getAllDocuments(): Flow<List<Document>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: Document): Long

    @Update
    suspend fun updateDocument(document: Document)

    @Delete
    suspend fun deleteDocument(document: Document)

    @Query("UPDATE documents SET lastOpenedAt = :time WHERE id = :id")
    suspend fun updateLastOpened(id: Long, time: Long)
}

// ==================== Database ====================

@Database(
    entities = [
        StudyAlarm::class,
        Quiz::class,
        Question::class,
        QuizResult::class,
        CurrentAffair::class,
        StudySession::class,
        Document::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    abstract fun quizDao(): QuizDao
    abstract fun questionDao(): QuestionDao
    abstract fun quizResultDao(): QuizResultDao
    abstract fun currentAffairsDao(): CurrentAffairsDao
    abstract fun documentDao(): DocumentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "upsc_agent_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
