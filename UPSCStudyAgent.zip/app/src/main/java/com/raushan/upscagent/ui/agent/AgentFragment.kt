package com.raushan.upscagent.ui.agent

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import com.raushan.upscagent.R
import com.raushan.upscagent.data.model.Document
import com.raushan.upscagent.data.repository.AppRepository
import com.raushan.upscagent.ui.reader.ReaderActivity
import com.raushan.upscagent.utils.MotivationHelper
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AgentFragment : Fragment() {

    private lateinit var repository: AppRepository
    private lateinit var docAdapter: DocumentAdapter
    private val documents = mutableListOf<Document>()

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                // Take persistable permission
                try {
                    requireContext().contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { /* ignore */ }

                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Document"
                val type = when {
                    name.endsWith(".pdf", true) -> "pdf"
                    name.endsWith(".html", true) || name.endsWith(".htm", true) -> "html"
                    else -> "txt"
                }

                viewLifecycleOwner.lifecycleScope.launch {
                    repository.insertDocument(Document(name = name, uri = uri.toString(), type = type))
                    Toast.makeText(context, "Document added!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_agent, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repository = AppRepository.getInstance(requireContext())

        val tvQuote = view.findViewById<TextView>(R.id.tv_agent_quote)
        val tvQuoteAuthor = view.findViewById<TextView>(R.id.tv_agent_quote_author)
        val tvTip = view.findViewById<TextView>(R.id.tv_agent_tip)
        val tvAdvice = view.findViewById<TextView>(R.id.tv_agent_daily_advice)
        val cardMotivation = view.findViewById<MaterialCardView>(R.id.card_new_motivation)
        val cardTip = view.findViewById<MaterialCardView>(R.id.card_new_tip)
        val cardSubjectAdvice = view.findViewById<MaterialCardView>(R.id.card_subject_advice)
        val cardAddDoc = view.findViewById<MaterialCardView>(R.id.card_add_document)
        val rvDocs = view.findViewById<RecyclerView>(R.id.rv_documents)
        val tvEmptyDocs = view.findViewById<TextView>(R.id.tv_empty_docs)

        // Set initial motivation
        refreshQuote(tvQuote, tvQuoteAuthor)
        tvTip.text = MotivationHelper.getRandomTip()
        tvAdvice.text = MotivationHelper.getDailyAdvice()

        // Refresh listeners
        cardMotivation.setOnClickListener { refreshQuote(tvQuote, tvQuoteAuthor) }
        cardTip.setOnClickListener { tvTip.text = MotivationHelper.getRandomTip() }

        // Subject advice dialog
        cardSubjectAdvice.setOnClickListener {
            val subjects = MotivationHelper.getAllSubjects().toTypedArray()
            AlertDialog.Builder(requireContext())
                .setTitle("Choose Subject")
                .setItems(subjects) { _, which ->
                    AlertDialog.Builder(requireContext())
                        .setTitle(subjects[which])
                        .setMessage(MotivationHelper.getSubjectAdvice(subjects[which]))
                        .setPositiveButton("OK", null)
                        .show()
                }
                .show()
        }

        // Document library
        docAdapter = DocumentAdapter(documents) { doc -> openDocument(doc) }
        rvDocs.layoutManager = LinearLayoutManager(context)
        rvDocs.adapter = docAdapter

        cardAddDoc.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/pdf", "text/plain", "text/html"
                ))
            }
            filePickerLauncher.launch(intent)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getAllDocuments().collectLatest { list ->
                documents.clear()
                documents.addAll(list)
                docAdapter.notifyDataSetChanged()
                tvEmptyDocs.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun refreshQuote(tvQuote: TextView, tvAuthor: TextView) {
        val quote = MotivationHelper.getRandomQuote()
        tvQuote.text = "\"${quote.text}\""
        tvAuthor.text = "— ${quote.author}"
    }

    private fun openDocument(doc: Document) {
        viewLifecycleOwner.lifecycleScope.launch { repository.updateDocLastOpened(doc.id) }
        val intent = Intent(context, ReaderActivity::class.java).apply {
            putExtra("doc_uri", doc.uri)
            putExtra("doc_name", doc.name)
            putExtra("doc_type", doc.type)
        }
        startActivity(intent)
    }

    // ========== Document Adapter ==========
    class DocumentAdapter(
        private val docs: List<Document>,
        private val onClick: (Document) -> Unit
    ) : RecyclerView.Adapter<DocumentAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvIcon: TextView = view.findViewById(R.id.tv_doc_icon)
            val tvName: TextView = view.findViewById(R.id.tv_doc_name)
            val tvType: TextView = view.findViewById(R.id.tv_doc_type)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_document, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val doc = docs[position]
            holder.tvIcon.text = when (doc.type) {
                "pdf" -> "📕"
                "html" -> "🌐"
                else -> "📄"
            }
            holder.tvName.text = doc.name
            holder.tvType.text = doc.type.uppercase()
            holder.itemView.setOnClickListener { onClick(doc) }
        }

        override fun getItemCount() = docs.size
    }
}
