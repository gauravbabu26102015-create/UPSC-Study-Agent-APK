package com.raushan.upscagent.data.repository

import android.content.Context
import com.raushan.upscagent.data.db.AppDatabase
import com.raushan.upscagent.data.model.*
import kotlinx.coroutines.flow.Flow

class AppRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val alarmDao = db.alarmDao()
    private val quizDao = db.quizDao()
    private val questionDao = db.questionDao()
    private val quizResultDao = db.quizResultDao()
    private val currentAffairsDao = db.currentAffairsDao()
    private val documentDao = db.documentDao()

    // ===== Alarms =====
    fun getAllAlarms(): Flow<List<StudyAlarm>> = alarmDao.getAllAlarms()
    suspend fun getEnabledAlarms(): List<StudyAlarm> = alarmDao.getEnabledAlarms()
    suspend fun getAlarmById(id: Long): StudyAlarm? = alarmDao.getAlarmById(id)
    suspend fun insertAlarm(alarm: StudyAlarm): Long = alarmDao.insertAlarm(alarm)
    suspend fun updateAlarm(alarm: StudyAlarm) = alarmDao.updateAlarm(alarm)
    suspend fun deleteAlarm(alarm: StudyAlarm) = alarmDao.deleteAlarm(alarm)
    suspend fun deleteAlarmById(id: Long) = alarmDao.deleteAlarmById(id)

    // ===== Quizzes =====
    fun getAllQuizzes(): Flow<List<Quiz>> = quizDao.getAllQuizzes()
    suspend fun getQuizById(id: Long): Quiz? = quizDao.getQuizById(id)
    suspend fun insertQuiz(quiz: Quiz): Long = quizDao.insertQuiz(quiz)
    suspend fun updateQuiz(quiz: Quiz) = quizDao.updateQuiz(quiz)
    suspend fun deleteQuiz(quiz: Quiz) = quizDao.deleteQuiz(quiz)
    suspend fun updateQuestionCount(quizId: Long) = quizDao.updateQuestionCount(quizId)

    // ===== Questions =====
    suspend fun getQuestionsForQuiz(quizId: Long): List<Question> = questionDao.getQuestionsForQuiz(quizId)
    suspend fun getQuestionCount(quizId: Long): Int = questionDao.getQuestionCount(quizId)
    suspend fun insertQuestion(question: Question): Long = questionDao.insertQuestion(question)
    suspend fun insertQuestions(questions: List<Question>) = questionDao.insertQuestions(questions)

    // ===== Quiz Results =====
    fun getAllResults(): Flow<List<QuizResult>> = quizResultDao.getAllResults()
    suspend fun insertResult(result: QuizResult): Long = quizResultDao.insertResult(result)

    // ===== Current Affairs =====
    fun getAllAffairs(): Flow<List<CurrentAffair>> = currentAffairsDao.getAllAffairs()
    fun getAffairsByCategory(category: String): Flow<List<CurrentAffair>> = currentAffairsDao.getAffairsByCategory(category)
    fun getBookmarkedAffairs(): Flow<List<CurrentAffair>> = currentAffairsDao.getBookmarkedAffairs()
    suspend fun getAffairById(id: Long): CurrentAffair? = currentAffairsDao.getAffairById(id)
    suspend fun insertAffairs(affairs: List<CurrentAffair>) = currentAffairsDao.insertAffairs(affairs)
    suspend fun setBookmarked(id: Long, bookmarked: Boolean) = currentAffairsDao.setBookmarked(id, bookmarked)
    suspend fun markAsRead(id: Long) = currentAffairsDao.markAsRead(id)
    suspend fun countByTitle(title: String): Int = currentAffairsDao.countByTitle(title)

    // ===== Documents =====
    fun getAllDocuments(): Flow<List<Document>> = documentDao.getAllDocuments()
    suspend fun insertDocument(document: Document): Long = documentDao.insertDocument(document)
    suspend fun updateDocument(document: Document) = documentDao.updateDocument(document)
    suspend fun deleteDocument(document: Document) = documentDao.deleteDocument(document)
    suspend fun updateDocLastOpened(id: Long) = documentDao.updateLastOpened(id, System.currentTimeMillis())

    companion object {
        @Volatile
        private var INSTANCE: AppRepository? = null

        fun getInstance(context: Context): AppRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = AppRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
