package com.raushan.upscagent.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.raushan.upscagent.service.AlarmService

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getLongExtra("alarm_id", -1)
        val subject = intent.getStringExtra("subject") ?: "Study Time"
        val isStart = intent.getBooleanExtra("is_start", true)
        val notes = intent.getStringExtra("notes") ?: ""

        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            putExtra("alarm_id", alarmId)
            putExtra("subject", subject)
            putExtra("is_start", isStart)
            putExtra("notes", notes)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }
}
