package com.raushan.upscagent.worker

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.raushan.upscagent.R
import com.raushan.upscagent.UPSCAgentApp
import com.raushan.upscagent.data.repository.AppRepository
import com.raushan.upscagent.ui.home.MainActivity
import com.raushan.upscagent.utils.CurrentAffairsFetcher

class CurrentAffairsWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val repository = AppRepository.getInstance(applicationContext)
            val affairs = CurrentAffairsFetcher.fetchAll()

            // Filter out already existing affairs
            val newAffairs = affairs.filter { affair ->
                repository.countByTitle(affair.title) == 0
            }

            if (newAffairs.isNotEmpty()) {
                repository.insertAffairs(newAffairs)
                sendNotification(newAffairs.size)
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    private fun sendNotification(count: Int) {
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            putExtra("open_tab", "current_affairs")
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(applicationContext, UPSCAgentApp.CHANNEL_AFFAIRS)
            .setSmallIcon(R.drawable.ic_newspaper)
            .setContentTitle("📰 New Current Affairs")
            .setContentText("$count new articles fetched. Read before your study session!")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(200, notification)
    }
}
