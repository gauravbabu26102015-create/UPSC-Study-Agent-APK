package com.raushan.upscagent.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import com.raushan.upscagent.R
import com.raushan.upscagent.utils.MotivationHelper

class HomeFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvGreeting = view.findViewById<TextView>(R.id.tv_greeting)
        val tvQuote = view.findViewById<TextView>(R.id.tv_quote)
        val tvQuoteAuthor = view.findViewById<TextView>(R.id.tv_quote_author)
        val tvDailyAdvice = view.findViewById<TextView>(R.id.tv_daily_advice)
        val tvStudyTip = view.findViewById<TextView>(R.id.tv_study_tip)
        val btnRefreshTip = view.findViewById<View>(R.id.btn_refresh_tip)
        val cardAlarm = view.findViewById<MaterialCardView>(R.id.card_goto_alarm)
        val cardQuiz = view.findViewById<MaterialCardView>(R.id.card_goto_quiz)
        val cardNews = view.findViewById<MaterialCardView>(R.id.card_goto_news)
        val cardAgent = view.findViewById<MaterialCardView>(R.id.card_goto_agent)

        // Set greeting
        tvGreeting.text = MotivationHelper.getGreeting()

        // Set quote
        val quote = MotivationHelper.getRandomQuote()
        tvQuote.text = "\"${quote.text}\""
        tvQuoteAuthor.text = "— ${quote.author}"

        // Set daily advice
        tvDailyAdvice.text = MotivationHelper.getDailyAdvice()

        // Set study tip
        tvStudyTip.text = MotivationHelper.getRandomTip()

        // Refresh tip button
        btnRefreshTip?.setOnClickListener {
            tvStudyTip.text = MotivationHelper.getRandomTip()
        }

        // Quick action cards - navigate to tabs
        val bottomNav = activity?.findViewById<BottomNavigationView>(R.id.bottom_nav)
        cardAlarm?.setOnClickListener { bottomNav?.selectedItemId = R.id.nav_alarm }
        cardQuiz?.setOnClickListener { bottomNav?.selectedItemId = R.id.nav_quiz }
        cardNews?.setOnClickListener { bottomNav?.selectedItemId = R.id.nav_current_affairs }
        cardAgent?.setOnClickListener { bottomNav?.selectedItemId = R.id.nav_agent }
    }
}
