package com.raushan.upscagent.ui.currentaffairs

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.raushan.upscagent.R
import com.raushan.upscagent.data.model.CurrentAffair
import com.raushan.upscagent.data.repository.AppRepository
import com.raushan.upscagent.utils.CurrentAffairsFetcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CurrentAffairsFragment : Fragment() {

    private lateinit var repository: AppRepository
    private lateinit var adapter: CurrentAffairsAdapter
    private val affairs = mutableListOf<CurrentAffair>()
    private var currentCategory = "All"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_current_affairs, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repository = AppRepository.getInstance(requireContext())

        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_current_affairs)
        val swipeRefresh = view.findViewById<SwipeRefreshLayout>(R.id.swipe_refresh)
        val chipGroup = view.findViewById<ChipGroup>(R.id.chip_group_categories)
        val tvEmpty = view.findViewById<TextView>(R.id.tv_empty_affairs)

        adapter = CurrentAffairsAdapter(affairs,
            onClick = { affair -> openDetail(affair) },
            onBookmark = { affair -> toggleBookmark(affair) }
        )
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        // Category chips
        val categories = listOf("All", "National", "International", "Economy", "Science & Tech", "Environment", "Polity", "Defence", "Social", "Bookmarked")
        categories.forEach { cat ->
            val chip = Chip(context).apply {
                text = cat
                isCheckable = true
                isChecked = cat == "All"
            }
            chipGroup.addView(chip)
        }

        chipGroup.setOnCheckedStateChangeListener { group, _ ->
            val selectedChip = group.findViewById<Chip>(group.checkedChipId)
            currentCategory = selectedChip?.text?.toString() ?: "All"
            loadAffairs()
        }

        swipeRefresh.setOnRefreshListener {
            fetchNewAffairs {
                swipeRefresh.isRefreshing = false
            }
        }

        loadAffairs()
    }

    private fun loadAffairs() {
        val tvEmpty = view?.findViewById<TextView>(R.id.tv_empty_affairs)
        val flow = when (currentCategory) {
            "All" -> repository.getAllAffairs()
            "Bookmarked" -> repository.getBookmarkedAffairs()
            else -> repository.getAffairsByCategory(currentCategory)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            flow.collectLatest { list ->
                affairs.clear()
                affairs.addAll(list)
                adapter.notifyDataSetChanged()
                tvEmpty?.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun fetchNewAffairs(onComplete: () -> Unit) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val fetched = withContext(Dispatchers.IO) { CurrentAffairsFetcher.fetchAll() }
                val newOnes = fetched.filter { repository.countByTitle(it.title) == 0 }
                if (newOnes.isNotEmpty()) {
                    repository.insertAffairs(newOnes)
                    Toast.makeText(context, "${newOnes.size} new articles!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "No new articles", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error fetching: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            onComplete()
        }
    }

    private fun openDetail(affair: CurrentAffair) {
        viewLifecycleOwner.lifecycleScope.launch { repository.markAsRead(affair.id) }
        val intent = Intent(context, CurrentAffairsDetailActivity::class.java).apply {
            putExtra("affair_id", affair.id)
        }
        startActivity(intent)
    }

    private fun toggleBookmark(affair: CurrentAffair) {
        viewLifecycleOwner.lifecycleScope.launch {
            repository.setBookmarked(affair.id, !affair.isBookmarked)
        }
    }

    // ========== Adapter ==========
    class CurrentAffairsAdapter(
        private val affairs: List<CurrentAffair>,
        private val onClick: (CurrentAffair) -> Unit,
        private val onBookmark: (CurrentAffair) -> Unit
    ) : RecyclerView.Adapter<CurrentAffairsAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvCategory: TextView = view.findViewById(R.id.tv_affair_category)
            val tvTitle: TextView = view.findViewById(R.id.tv_affair_title)
            val tvSummary: TextView = view.findViewById(R.id.tv_affair_summary)
            val tvSource: TextView = view.findViewById(R.id.tv_affair_source)
            val btnBookmark: TextView = view.findViewById(R.id.btn_bookmark)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_current_affair, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val affair = affairs[position]
            holder.tvCategory.text = affair.category
            holder.tvTitle.text = affair.title
            holder.tvSummary.text = affair.summary
            holder.tvSource.text = affair.source
            holder.btnBookmark.text = if (affair.isBookmarked) "★" else "☆"
            holder.itemView.setOnClickListener { onClick(affair) }
            holder.btnBookmark.setOnClickListener { onBookmark(affair) }
            holder.itemView.alpha = if (affair.isRead) 0.7f else 1.0f
        }

        override fun getItemCount() = affairs.size
    }
}
