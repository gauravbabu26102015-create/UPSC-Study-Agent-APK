package com.raushan.upscagent.ui.quiz

import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.raushan.upscagent.R
import com.raushan.upscagent.data.model.Question
import com.raushan.upscagent.data.model.QuizResult
import com.raushan.upscagent.data.repository.AppRepository
import kotlinx.coroutines.launch

class QuizActivity : AppCompatActivity() {

    private lateinit var repository: AppRepository
    private var questions = listOf<Question>()
    private var currentIndex = 0
    private var score = 0
    private var wrong = 0
    private var skipped = 0
    private var selectedOption = -1
    private var answered = false
    private var startTime = 0L

    private lateinit var tvProgress: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvQuestion: TextView
    private lateinit var cards: List<CardView>
    private lateinit var tvOptions: List<TextView>
    private lateinit var tvExplanation: TextView
    private lateinit var btnSkip: Button
    private lateinit var btnNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)
        repository = AppRepository.getInstance(this)

        val quizId = intent.getLongExtra("quiz_id", -1)
        val quizTitle = intent.getStringExtra("quiz_title") ?: "Quiz"

        findViewById<TextView>(R.id.tv_quiz_toolbar_title).text = quizTitle
        findViewById<View>(R.id.btn_quiz_back).setOnClickListener { finish() }

        tvProgress = findViewById(R.id.tv_quiz_progress)
        progressBar = findViewById(R.id.quiz_progress_bar)
        tvQuestion = findViewById(R.id.tv_question_text)
        tvExplanation = findViewById(R.id.tv_explanation)
        btnSkip = findViewById(R.id.btn_skip)
        btnNext = findViewById(R.id.btn_next)

        cards = listOf(
            findViewById(R.id.card_option_a),
            findViewById(R.id.card_option_b),
            findViewById(R.id.card_option_c),
            findViewById(R.id.card_option_d)
        )
        tvOptions = listOf(
            findViewById(R.id.tv_option_a),
            findViewById(R.id.tv_option_b),
            findViewById(R.id.tv_option_c),
            findViewById(R.id.tv_option_d)
        )

        startTime = SystemClock.elapsedRealtime()

        lifecycleScope.launch {
            questions = repository.getQuestionsForQuiz(quizId)
            if (questions.isEmpty()) {
                Toast.makeText(this@QuizActivity, "No questions found", Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            showQuestion()
        }

        // Option click listeners
        cards.forEachIndexed { index, card ->
            card.setOnClickListener {
                if (!answered) selectOption(index)
            }
        }

        btnSkip.setOnClickListener {
            if (!answered) {
                skipped++
                nextQuestion()
            }
        }

        btnNext.setOnClickListener {
            if (!answered && selectedOption >= 0) {
                checkAnswer()
            } else if (answered) {
                nextQuestion()
            }
        }
    }

    private fun showQuestion() {
        if (currentIndex >= questions.size) {
            showResults()
            return
        }

        val q = questions[currentIndex]
        answered = false
        selectedOption = -1

        tvProgress.text = "Question ${currentIndex + 1}/${questions.size}"
        progressBar.max = questions.size
        progressBar.progress = currentIndex + 1
        tvQuestion.text = q.questionText
        tvExplanation.visibility = View.GONE

        val options = listOf(q.optionA, q.optionB, q.optionC, q.optionD)
        tvOptions.forEachIndexed { index, tv ->
            tv.text = "${('A' + index)}) ${options[index]}"
        }

        // Reset card colors
        cards.forEach { card ->
            card.setCardBackgroundColor(ContextCompat.getColor(this, R.color.white))
            card.visibility = View.VISIBLE
        }
        // Hide empty options
        if (questions[currentIndex].optionC.isBlank()) cards[2].visibility = View.GONE
        if (questions[currentIndex].optionD.isBlank()) cards[3].visibility = View.GONE

        btnNext.text = "Check Answer"
        btnSkip.visibility = View.VISIBLE
    }

    private fun selectOption(index: Int) {
        selectedOption = index
        cards.forEachIndexed { i, card ->
            card.setCardBackgroundColor(
                ContextCompat.getColor(this,
                    if (i == index) R.color.primary_light else R.color.white
                )
            )
        }
    }

    private fun checkAnswer() {
        answered = true
        val q = questions[currentIndex]

        if (selectedOption == q.correctAnswer) {
            score++
            cards[selectedOption].setCardBackgroundColor(ContextCompat.getColor(this, R.color.success))
        } else {
            wrong++
            if (selectedOption >= 0) {
                cards[selectedOption].setCardBackgroundColor(ContextCompat.getColor(this, R.color.error))
            }
            cards[q.correctAnswer].setCardBackgroundColor(ContextCompat.getColor(this, R.color.success))
        }

        if (q.explanation.isNotBlank()) {
            tvExplanation.text = "💡 ${q.explanation}"
            tvExplanation.visibility = View.VISIBLE
        }

        btnNext.text = if (currentIndex < questions.size - 1) "Next →" else "See Results"
        btnSkip.visibility = View.GONE
    }

    private fun nextQuestion() {
        currentIndex++
        showQuestion()
    }

    private fun showResults() {
        val timeTaken = (SystemClock.elapsedRealtime() - startTime) / 1000
        val percentage = if (questions.isNotEmpty()) (score.toFloat() / questions.size * 100) else 0f

        // Save result
        lifecycleScope.launch {
            repository.insertResult(
                QuizResult(
                    quizId = intent.getLongExtra("quiz_id", -1),
                    quizTitle = intent.getStringExtra("quiz_title") ?: "Quiz",
                    totalQuestions = questions.size,
                    correctAnswers = score,
                    wrongAnswers = wrong,
                    skippedAnswers = skipped,
                    timeTakenSeconds = timeTaken,
                    percentage = percentage
                )
            )
        }

        val minutes = timeTaken / 60
        val seconds = timeTaken % 60

        AlertDialog.Builder(this)
            .setTitle("🎉 Quiz Complete!")
            .setMessage(
                "Score: $score/${questions.size} (${String.format("%.1f", percentage)}%)\n\n" +
                "✅ Correct: $score\n" +
                "❌ Wrong: $wrong\n" +
                "⏭️ Skipped: $skipped\n" +
                "⏱️ Time: ${minutes}m ${seconds}s"
            )
            .setPositiveButton("Done") { _, _ -> finish() }
            .setNeutralButton("Retry") { _, _ ->
                currentIndex = 0; score = 0; wrong = 0; skipped = 0
                startTime = SystemClock.elapsedRealtime()
                showQuestion()
            }
            .setCancelable(false)
            .show()
    }
}
