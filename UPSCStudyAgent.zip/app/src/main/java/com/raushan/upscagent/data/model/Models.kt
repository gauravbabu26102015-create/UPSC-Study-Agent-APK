package com.raushan.upscagent.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import androidx.room.Index

/**
 * Study Alarm - represents a scheduled study session alarm
 */
@Entity(tableName = "study_alarms")
data class StudyAlarm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val startHour: Int,
    val startMinute: Int,
    val endHour: Int,
    val endMinute: Int,
    val daysOfWeek: String = "1,2,3,4,5,6,7", // 1=Mon...7=Sun comma separated
    val isEnabled: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Quiz - a collection of questions
 */
@Entity(tableName = "quizzes")
data class Quiz(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String = "General",
    val questionCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Question - belongs to a Quiz
 */
@Entity(
    tableName = "questions",
    foreignKeys = [ForeignKey(
        entity = Quiz::class,
        parentColumns = ["id"],
        childColumns = ["quizId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("quizId")]
)
data class Question(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val quizId: Long,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String = "",
    val optionD: String = "",
    val correctAnswer: Int = 0, // 0=A, 1=B, 2=C, 3=D
    val explanation: String = ""
)

/**
 * Quiz Result - saved after completing a quiz
 */
@Entity(tableName = "quiz_results")
data class QuizResult(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val quizId: Long,
    val quizTitle: String,
    val totalQuestions: Int,
    val correctAnswers: Int,
    val wrongAnswers: Int,
    val skippedAnswers: Int,
    val timeTakenSeconds: Long,
    val percentage: Float,
    val completedAt: Long = System.currentTimeMillis()
)

/**
 * Current Affair - news article fetched from web
 */
@Entity(tableName = "current_affairs")
data class CurrentAffair(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val summary: String,
    val content: String = "",
    val source: String,
    val sourceUrl: String = "",
    val category: String = "General",
    val isRead: Boolean = false,
    val isBookmarked: Boolean = false,
    val publishedAt: Long = System.currentTimeMillis(),
    val fetchedAt: Long = System.currentTimeMillis()
)

/**
 * Study Session - tracks study time
 */
@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val durationMinutes: Int,
    val date: Long = System.currentTimeMillis()
)

/**
 * Document - saved document reference for reader
 */
@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val uri: String,
    val type: String, // "pdf", "html", "txt"
    val addedAt: Long = System.currentTimeMillis(),
    val lastOpenedAt: Long = 0
)
