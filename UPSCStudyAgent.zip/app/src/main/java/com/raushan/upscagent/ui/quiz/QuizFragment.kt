package com.raushan.upscagent.ui.quiz

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.raushan.upscagent.R
import com.raushan.upscagent.data.model.Question
import com.raushan.upscagent.data.model.Quiz
import com.raushan.upscagent.data.repository.AppRepository
import com.raushan.upscagent.utils.PDFQuizParser
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class QuizFragment : Fragment() {

    private lateinit var repository: AppRepository
    private lateinit var adapter: QuizListAdapter
    private val quizzes = mutableListOf<Quiz>()

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                importQuizFromFile(uri)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repository = AppRepository.getInstance(requireContext())

        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_quizzes)
        val fabAdd = view.findViewById<FloatingActionButton>(R.id.fab_add_quiz)
        val tvEmpty = view.findViewById<TextView>(R.id.tv_empty_quizzes)

        adapter = QuizListAdapter(quizzes,
            onStart = { quiz -> startQuiz(quiz) },
            onDelete = { quiz -> deleteQuiz(quiz) },
            onAddQuestion = { quiz -> showAddQuestionDialog(quiz) }
        )
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        fabAdd.setOnClickListener { showQuizOptionsDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            repository.getAllQuizzes().collectLatest { list ->
                quizzes.clear()
                quizzes.addAll(list)
                adapter.notifyDataSetChanged()
                tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun showQuizOptionsDialog() {
        val options = arrayOf("Create Manual Quiz", "Import from File (TXT)")
        AlertDialog.Builder(requireContext())
            .setTitle("Add Quiz")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showCreateQuizDialog()
                    1 -> openFilePicker()
                }
            }
            .show()
    }

    private fun showCreateQuizDialog() {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_create_quiz, null)
        val etTitle = dialogView.findViewById<EditText>(R.id.et_quiz_title)
        val etSubject = dialogView.findViewById<EditText>(R.id.et_quiz_subject)

        AlertDialog.Builder(requireContext())
            .setTitle("Create Quiz")
            .setView(dialogView)
            .setPositiveButton("Create") { _, _ ->
                val title = etTitle.text.toString().trim()
                if (title.isBlank()) {
                    Toast.makeText(context, "Enter quiz title", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val subject = etSubject.text.toString().trim().ifBlank { "General" }
                viewLifecycleOwner.lifecycleScope.launch {
                    repository.insertQuiz(Quiz(title = title, subject = subject))
                    Toast.makeText(context, "Quiz created! Add questions to it.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddQuestionDialog(quiz: Quiz) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_question, null)
        val etQuestion = dialogView.findViewById<EditText>(R.id.et_question_text)
        val etOptA = dialogView.findViewById<EditText>(R.id.et_option_a)
        val etOptB = dialogView.findViewById<EditText>(R.id.et_option_b)
        val etOptC = dialogView.findViewById<EditText>(R.id.et_option_c)
        val etOptD = dialogView.findViewById<EditText>(R.id.et_option_d)
        val rgCorrect = dialogView.findViewById<RadioGroup>(R.id.rg_correct_answer)
        val etExplanation = dialogView.findViewById<EditText>(R.id.et_explanation)

        AlertDialog.Builder(requireContext())
            .setTitle("Add Question to ${quiz.title}")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val questionText = etQuestion.text.toString().trim()
                if (questionText.isBlank() || etOptA.text.isBlank() || etOptB.text.isBlank()) {
                    Toast.makeText(context, "Fill question and at least 2 options", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val correct = when (rgCorrect.checkedRadioButtonId) {
                    R.id.rb_option_a -> 0
                    R.id.rb_option_b -> 1
                    R.id.rb_option_c -> 2
                    R.id.rb_option_d -> 3
                    else -> 0
                }

                viewLifecycleOwner.lifecycleScope.launch {
                    repository.insertQuestion(
                        Question(
                            quizId = quiz.id,
                            questionText = questionText,
                            optionA = etOptA.text.toString().trim(),
                            optionB = etOptB.text.toString().trim(),
                            optionC = etOptC.text.toString().trim(),
                            optionD = etOptD.text.toString().trim(),
                            correctAnswer = correct,
                            explanation = etExplanation.text.toString().trim()
                        )
                    )
                    repository.updateQuestionCount(quiz.id)
                    Toast.makeText(context, "Question added!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
        }
        filePickerLauncher.launch(intent)
    }

    private fun importQuizFromFile(uri: android.net.Uri) {
        viewLifecycleOwner.lifecycleScope.launch {
            val text = PDFQuizParser.readTextFromUri(requireContext(), uri)
            if (text.isBlank()) {
                Toast.makeText(context, "Could not read file", Toast.LENGTH_SHORT).show()
                return@launch
            }

            // Create quiz first
            val quizId = repository.insertQuiz(Quiz(title = "Imported Quiz", subject = "General"))
            val result = PDFQuizParser.parseText(text, quizId)

            if (result.questions.isNotEmpty()) {
                repository.insertQuestions(result.questions)
                repository.updateQuestionCount(quizId)
                Toast.makeText(context, "Imported ${result.totalFound} questions!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "No questions found in file. ${result.errors.firstOrNull() ?: ""}", Toast.LENGTH_LONG).show()
                repository.deleteQuiz(Quiz(id = quizId, title = ""))
            }
        }
    }

    private fun startQuiz(quiz: Quiz) {
        viewLifecycleOwner.lifecycleScope.launch {
            val count = repository.getQuestionCount(quiz.id)
            if (count == 0) {
                Toast.makeText(context, "No questions in this quiz. Add some first!", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val intent = Intent(context, QuizActivity::class.java).apply {
                putExtra("quiz_id", quiz.id)
                putExtra("quiz_title", quiz.title)
            }
            startActivity(intent)
        }
    }

    private fun deleteQuiz(quiz: Quiz) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Quiz")
            .setMessage("Delete '${quiz.title}' and all its questions?")
            .setPositiveButton("Delete") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch { repository.deleteQuiz(quiz) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ========== Adapter ==========
    class QuizListAdapter(
        private val quizzes: List<Quiz>,
        private val onStart: (Quiz) -> Unit,
        private val onDelete: (Quiz) -> Unit,
        private val onAddQuestion: (Quiz) -> Unit
    ) : RecyclerView.Adapter<QuizListAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvTitle: TextView = view.findViewById(R.id.tv_quiz_title)
            val tvSubject: TextView = view.findViewById(R.id.tv_quiz_subject)
            val tvCount: TextView = view.findViewById(R.id.tv_quiz_count)
            val btnStart: View = view.findViewById(R.id.btn_start_quiz)
            val btnAddQ: View = view.findViewById(R.id.btn_add_question)
            val btnDelete: View = view.findViewById(R.id.btn_delete_quiz)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_quiz, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val quiz = quizzes[position]
            holder.tvTitle.text = quiz.title
            holder.tvSubject.text = quiz.subject
            holder.tvCount.text = "${quiz.questionCount} questions"
            holder.btnStart.setOnClickListener { onStart(quiz) }
            holder.btnAddQ.setOnClickListener { onAddQuestion(quiz) }
            holder.btnDelete.setOnClickListener { onDelete(quiz) }
        }

        override fun getItemCount() = quizzes.size
    }
}
