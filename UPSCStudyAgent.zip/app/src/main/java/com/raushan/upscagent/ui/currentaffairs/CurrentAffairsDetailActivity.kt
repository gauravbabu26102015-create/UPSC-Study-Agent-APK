package com.raushan.upscagent.ui.currentaffairs

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.raushan.upscagent.R
import com.raushan.upscagent.data.repository.AppRepository
import kotlinx.coroutines.launch

class CurrentAffairsDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_current_affairs_detail)

        val affairId = intent.getLongExtra("affair_id", -1)
        val repository = AppRepository.getInstance(this)

        val tvTitle = findViewById<TextView>(R.id.tv_detail_title)
        val tvSource = findViewById<TextView>(R.id.tv_detail_source)
        val tvCategory = findViewById<TextView>(R.id.tv_detail_category)
        val tvContent = findViewById<TextView>(R.id.tv_detail_content)
        val btnOpenSource = findViewById<Button>(R.id.btn_open_source)
        val btnBack = findViewById<View>(R.id.btn_detail_back)

        btnBack.setOnClickListener { finish() }

        lifecycleScope.launch {
            val affair = repository.getAffairById(affairId)
            if (affair != null) {
                tvTitle.text = affair.title
                tvSource.text = "Source: ${affair.source}"
                tvCategory.text = affair.category
                tvContent.text = affair.content.ifBlank { affair.summary }

                if (affair.sourceUrl.isNotBlank()) {
                    btnOpenSource.setOnClickListener {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(affair.sourceUrl)))
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                } else {
                    btnOpenSource.visibility = android.view.View.GONE
                }
            }
        }
    }
}
