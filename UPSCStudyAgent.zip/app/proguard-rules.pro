# Keep Room entities
-keep class com.raushan.upscagent.data.model.** { *; }

# Jsoup
-keeppackagenames org.jsoup.nodes

# PDF Viewer
-keep class com.shockwave.**
